library(testthat)
library(specificity)

capture.output(test_check("specificity"), file="../test_results.txt")
