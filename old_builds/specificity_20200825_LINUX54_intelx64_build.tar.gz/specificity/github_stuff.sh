# run once:
# git init
# git add .
# git commit -m "first commit"
# git remote add origin https://github.com/darcyj/specificity.git
# git push -u origin master


git add .
git commit -m 04sept2019 #(or whatever today's date is)
git push origin master
